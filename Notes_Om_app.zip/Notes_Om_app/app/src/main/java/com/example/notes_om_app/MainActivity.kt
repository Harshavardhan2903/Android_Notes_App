package com.example.notes_om_app

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.SearchView
import androidx.activity.result.contract.ActivityResultContract
import androidx.activity.result.contract.ActivityResultContracts
import androidx.cardview.widget.CardView
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.example.notes_om_app.Models.Note
import com.example.notes_om_app.Models.NotesViewModel
import com.example.notes_om_app.adapter.NotesAdapter
import com.example.notes_om_app.database.Notedatabase
import com.example.notes_om_app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() ,NotesAdapter.NotesitemClickListener,PopupMenu.OnMenuItemClickListener{

    //implementing binding
    private lateinit var binding : ActivityMainBinding
    private lateinit var database : Notedatabase
    lateinit var viewmodel : NotesViewModel
    lateinit var adapter: NotesAdapter
    lateinit var selectednote : Note


    private val updateNote = registerForActivityResult(ActivityResultContracts.StartActivityForResult()){
        result->
        if(result.resultCode == Activity.RESULT_OK){
            val note = result.data?.getSerializableExtra("note") as? Note
            if(note!=null){
                viewmodel.updateNote(note)
            }

        }
    }

    //above : A binding class is genrerated for each layout file . for activity_main it is ActivityMainBinding . It holds all layout properties

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        funinitUI()

        viewmodel = ViewModelProvider(this,ViewModelProvider.AndroidViewModelFactory.getInstance(application)).get(NotesViewModel::class.java)

        viewmodel.allnotes.observe(this) {list ->
            list?.let{
                adapter.updatelist(list)  //will observe notes and if change then will call update list
            }

        }

        database = Notedatabase.getDB(this)

    }

    private fun funinitUI() {

        binding.recyclerView.setHasFixedSize(true)
        binding.recyclerView.layoutManager = StaggeredGridLayoutManager(2,LinearLayout.VERTICAL)
        adapter = NotesAdapter(this , this)
        binding.recyclerView.adapter = adapter

        val getContent  = registerForActivityResult(ActivityResultContracts.StartActivityForResult() ){   //for user clicking on floating action button
            result ->
            if(result.resultCode == Activity.RESULT_OK){
                val note = result.data?.getSerializableExtra("note") as? Note
                if(note!=null){
                    viewmodel.insertnote(note)
                }
            }
        }

        binding.floatingActionButton6.setOnClickListener {
            val intent = Intent(this,add_note::class.java) //so whenever user clicks button next activity add_note launched
            getContent.launch(intent)   //this launnched as result activity
        }

        binding.search.setOnQueryTextListener(object : SearchView.OnQueryTextListener{
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false //when he submits we dont care
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                if(newText!=null){
                    adapter.filterList(newText)
                }
                return true
            }

        })
    }

    override fun onitemclicked(note: Note) {
        val intent = Intent(this@MainActivity,add_note::class.java)
        intent.putExtra("current_note",note)
        updateNote.launch(intent)


    }

    override fun onlongitemClicked(note: Note, cardView: CardView) {
        selectednote = note
        funpopupdisplay(cardView)
    }

    private fun funpopupdisplay(cardview: CardView) {
        val popup = PopupMenu(this,cardview)
        popup.setOnMenuItemClickListener(this@MainActivity)
        popup.inflate(R.menu.pop_up_menu)
        popup.show()
    }

    override fun onMenuItemClick(item: MenuItem?): Boolean {
        if(item?.itemId == R.id.deletenote){
            viewmodel.deletenote(selectednote)
            return true
        }
        return false
    }


}