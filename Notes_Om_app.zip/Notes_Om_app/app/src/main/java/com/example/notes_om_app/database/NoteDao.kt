package com.example.notes_om_app.database

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.notes_om_app.Models.Note


@Dao //annotating for room db purpose
interface NoteDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE) //annotating for room db
    suspend fun funinsertNote(note: Note) //Note this is a normal function

    //we actually annotate as we want to update db as this function is called

    @Delete
    suspend fun fundeletenote(note:Note)

    @Query("Select * from notes_table order by id ASC")
    fun fungetalldata() : LiveData<List<Note>>   //this probably wont be called from inside a coroutine and retuns list of notes

    @Query("Update notes_table set title = :n_title where id = :n_id ")
    suspend fun funupdatenote(n_id : Int? , n_title : String?)
}