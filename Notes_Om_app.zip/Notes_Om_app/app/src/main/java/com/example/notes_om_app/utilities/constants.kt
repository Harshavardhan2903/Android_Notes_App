package com.example.notes_om_app.utilities

const val DATABASE_NAME = "note_database"