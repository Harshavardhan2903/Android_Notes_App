package com.example.notes_om_app.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.cardview.R
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.example.notes_om_app.Models.Note
import kotlin.random.Random

class NotesAdapter(private val context: Context , val listener:NotesitemClickListener):RecyclerView.Adapter<NotesAdapter.NotesViewholder>() {

   private val NotesList = ArrayList<Note>()
   private val fullList = ArrayList<Note>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NotesViewholder {
        return NotesViewholder(
            LayoutInflater.from(context).inflate(com.example.notes_om_app.R.layout.list,parent,false)
        )
    }

    override fun getItemCount(): Int {
        return NotesList.size
    }

    override fun onBindViewHolder(holder: NotesViewholder, position: Int) {
        val currentNote = NotesList[position]
        holder.title_cum_note.text = currentNote.title
        holder.title_cum_note.isSelected = true

        holder.date.text = currentNote.date
        holder.date.isSelected = true

        holder.notes_layout.setCardBackgroundColor(holder.itemView.resources.getColor(randomcolor(),null))

        holder.notes_layout.setOnClickListener {
            listener.onitemclicked(NotesList[holder.adapterPosition])
        }

        holder.notes_layout.setOnLongClickListener {
            listener.onlongitemClicked(NotesList[holder.adapterPosition],holder.notes_layout)
            true
        }
    }

    fun updatelist(newList: List<Note>){
        fullList.clear()
        fullList.addAll(newList)
        NotesList.clear()
        NotesList.addAll(fullList)
        notifyDataSetChanged()
    }

    fun filterList(search : String){
        NotesList.clear()
        for(item in fullList){
            if(item.title?.lowercase()?.contains(search.lowercase()) == true){
                NotesList.add(item)
            }
        }

        notifyDataSetChanged()//to inform app to refresh data inside recycler view
    }



    fun randomcolor():Int{
        val list = ArrayList<Int>()
        list.add(com.example.notes_om_app.R.color.NoteC1)
        list.add(com.example.notes_om_app.R.color.NoteC2)
        list.add(com.example.notes_om_app.R.color.NoteC3)
        list.add(com.example.notes_om_app.R.color.NoteC4)
        list.add(com.example.notes_om_app.R.color.NoteC5)
        list.add(com.example.notes_om_app.R.color.NoteC6)

        val seed  = System.currentTimeMillis()
        val randomind = Random(seed).nextInt(list.size)   //the seed changes with time so no rep
        return list[randomind]
    }

    inner class NotesViewholder(itemView:View) : RecyclerView.ViewHolder(itemView){
        val notes_layout  = itemView.findViewById<CardView>(com.example.notes_om_app.R.id.item_cardd)
        val title_cum_note = itemView.findViewById<TextView>(com.example.notes_om_app.R.id.t_name)
        val date  = itemView.findViewById<TextView>(com.example.notes_om_app.R.id.t_date)
    }

    interface NotesitemClickListener{
        fun onitemclicked(note:Note)
        fun onlongitemClicked(note:Note,cardView: CardView)
    }
}