package com.example.notes_om_app.database

import androidx.lifecycle.LiveData
import com.example.notes_om_app.Models.Note

class NotesRepository(private val Notedao :NoteDao) {
    val allNotes : LiveData<List<Note>> = Notedao.fungetalldata()     //repo is where we store the data , we get data from db through methods defined in doa

    suspend fun insert(note:Note){
        Notedao.funinsertNote(note)
    }

    suspend fun delete(note:Note){
        Notedao.fundeletenote(note)
    }

    suspend fun update(note:Note){
        Notedao.funupdatenote(note.id , note.title)
    }
}