package com.example.notes_om_app.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.notes_om_app.Models.Note
import com.example.notes_om_app.utilities.DATABASE_NAME


@Database(entities = arrayOf(Note::class), version = 1 , exportSchema = false)
abstract   //Still a class but with room's annotations
class Notedatabase :RoomDatabase(){

    abstract fun getNoteDao() : NoteDao


    // to create only one instance of db
    companion object{
        @Volatile
        private var INSTANCE : Notedatabase? = null

        fun getDB(context :Context) : Notedatabase{   // checks for wheteher reference is already there
            return INSTANCE ?: synchronized(this){    //this class should be synchronized with first operation so that at next we know is was used
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    Notedatabase::class.java,
                    DATABASE_NAME
                ).build()
                INSTANCE = instance

                instance
            }
        }

    }
}