package com.example.notes_om_app.Models

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

//have created this to act as a data class , i.e data type to store our notes

//then push into db

@Entity(tableName = "notes_table") //annotated as we are using this data type in room db
data class Note(
    @PrimaryKey(autoGenerate = true) val id :Int?, // left side annotation shit is for room
    @ColumnInfo(name = "title")  val title:String? ,
    @ColumnInfo(name = "date") val date :String?
) : java.io.Serializable  //to pass through intents

//tells how object of this class will look like
